package org.example;

import java.sql.SQLOutput;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
       /* Pattern pattern = Pattern.compile("Jantschge");
        Matcher matcher = pattern.matcher("Manuel Jantschge");
        if(matcher.find()){
            System.out.println("Yuhu");
            System.out.println("Group: " + matcher.group() + "found at pos" + matcher.start());
        }else{
            System.out.println("Pfui");
        }*/
        /*Pattern pattern = Pattern.compile("^(0|1)*(00|01)$");
        Matcher matcher = pattern.matcher("01");
        if(matcher.find()){
            System.out.println("Hui");
        }
        if(pattern.matcher("00").find()){
            System.out.println("Hui");
        }
        if(pattern.matcher("0100111").find()){
            System.out.println("Pfui");
        }
        if(pattern.matcher("ahfhdkjfdh01").find()){
            System.out.println("Pfui");
        }*/
        /*Pattern pattern = Pattern.compile("B[iu]rma");
        Matcher matcher = pattern.matcher("Birma");
        if(matcher.find()){
            System.out.println(matcher.group());
        }*/
        /*Pattern pattern = Pattern.compile("<h[1-6]>");
        Matcher matcher = pattern.matcher("<h6>");
        if(matcher.find()){
            System.out.println(matcher.group());
        }*/
        // Repetitions additional to *
        // Pattern pattern = Pattern.compile("[a-zA-Z0-9]+");//One or more characters with +
        //Pattern pattern = Pattern.compile("[a-zA-Z0-9]{3}");//3 characters with
        Pattern pattern = Pattern.compile("[a-zA-Z0-9]{2,4}");//Zwischen 2 und 4 occurence

        Matcher matcher = pattern.matcher("Woswasi");
        while(matcher.find()){
            System.out.println(matcher.group() + " at " + matcher.start());
        }
    }
}
